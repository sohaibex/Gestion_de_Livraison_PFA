package com.livraison.Livraison;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivraisonApplicationTests {

	@Test
	void contextLoads() {
	}

}
